import { Module } from '@nestjs/common';
import { AuthModule } from './modules/auth/auth.module';
import { ProductsModule } from './modules/products/products.module';
import { PaymentsModule } from './modules/payments/payments.module';

@Module({
  imports: [AuthModule, ProductsModule, PaymentsModule],
})
export class AppModule {}