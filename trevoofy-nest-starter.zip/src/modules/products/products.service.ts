import { Injectable } from '@nestjs/common';

@Injectable()
export class ProductsService {
  private products = [{ id: 1, name: 'Curso Teste', price: 99.9 }];

  findAll() {
    return this.products;
  }
}