import { Injectable } from '@nestjs/common';

@Injectable()
export class PaymentsService {
  createCheckout(productId: number) {
    return { checkoutUrl: `https://fake-checkout.trevoofy.com/${productId}` };
  }
}