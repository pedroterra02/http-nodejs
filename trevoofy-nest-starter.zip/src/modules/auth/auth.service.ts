import { Injectable } from '@nestjs/common';

@Injectable()
export class AuthService {
  login(user: string, pass: string) {
    if (user === 'admin' && pass === '123') {
      return { token: 'fake-jwt-token' };
    }
    return { error: 'Invalid credentials' };
  }
}